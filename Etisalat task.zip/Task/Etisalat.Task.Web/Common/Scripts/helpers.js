﻿var App = App || {};
(function () {

    var appLocalizationSource = abp.localization.getSource('Task');
    App.localize = function () {
        return appLocalizationSource.apply(this, arguments);
    };

})(App);