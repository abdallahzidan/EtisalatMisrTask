﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Etisalat.Task.Roles.Dto;

namespace Etisalat.Task.Roles
{
    public interface IRoleAppService : IApplicationService
    {
        Task UpdateRolePermissions(UpdateRolePermissionsInput input);
    }
}
