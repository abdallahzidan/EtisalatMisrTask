﻿using System.Data.Common;
using Abp.Zero.EntityFramework;
using Etisalat.Task.Authorization.Roles;
using Etisalat.Task.MultiTenancy;
using Etisalat.Task.Users;

namespace Etisalat.Task.EntityFramework
{
    public class TaskDbContext : AbpZeroDbContext<Tenant, Role, User>
    {
        //TODO: Define an IDbSet for your Entities...

        /* NOTE: 
         *   Setting "Default" to base class helps us when working migration commands on Package Manager Console.
         *   But it may cause problems when working Migrate.exe of EF. If you will apply migrations on command line, do not
         *   pass connection string name to base classes. ABP works either way.
         */
        public TaskDbContext()
            : base("Default")
        {

        }

        /* NOTE:
         *   This constructor is used by ABP to pass connection string defined in TaskDataModule.PreInitialize.
         *   Notice that, actually you will not directly create an instance of TaskDbContext since ABP automatically handles it.
         */
        public TaskDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {

        }

        //This constructor is used in tests
        public TaskDbContext(DbConnection connection)
            : base(connection, true)
        {

        }
    }
}
