﻿using Abp.Domain.Entities;
using Abp.EntityFramework;
using Abp.EntityFramework.Repositories;

namespace Etisalat.Task.EntityFramework.Repositories
{
    public abstract class TaskRepositoryBase<TEntity, TPrimaryKey> : EfRepositoryBase<TaskDbContext, TEntity, TPrimaryKey>
        where TEntity : class, IEntity<TPrimaryKey>
    {
        protected TaskRepositoryBase(IDbContextProvider<TaskDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //add common methods for all repositories
    }

    public abstract class TaskRepositoryBase<TEntity> : TaskRepositoryBase<TEntity, int>
        where TEntity : class, IEntity<int>
    {
        protected TaskRepositoryBase(IDbContextProvider<TaskDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //do not add any method here, add to the class above (since this inherits it)
    }
}
