﻿namespace Etisalat.Task
{
    public class TaskConsts
    {
        public const string LocalizationSourceName = "Task";
    }
}