﻿using Abp.Authorization;
using Etisalat.Task.Authorization.Roles;
using Etisalat.Task.MultiTenancy;
using Etisalat.Task.Users;

namespace Etisalat.Task.Authorization
{
    public class PermissionChecker : PermissionChecker<Tenant, Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
