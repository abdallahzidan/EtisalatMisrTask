﻿using Abp.MultiTenancy;
using Etisalat.Task.Users;

namespace Etisalat.Task.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}